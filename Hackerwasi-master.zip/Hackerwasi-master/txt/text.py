text = ['Press F to hack', ' Hacekr wasii', 'Best OSINT Tool', 'Pakistan black Mafia', 'Twitter: Hackerwasii', 'insta : Hackerwasii', 'website : hackerwasii.com', 'BlackHat Hacker', 'Waseem Akram']
